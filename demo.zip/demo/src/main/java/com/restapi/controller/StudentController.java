package com.restapi.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.restapi.entities.Student;
import com.restapi.service.StudentService;

import java.util.List;
import java.util.Optional;

@RestController
public class StudentController {
	
	@Autowired
	private StudentService service;
	
	@PostMapping("/student")
	public Student saveStudent(@RequestBody Student student) {
		return service.saveStudent(student);
		
	}
	
	@GetMapping("/student")
	public List<Student> getAllStudents() {
		return service.getAllStudent();
		
	}
	
	@GetMapping("/student/{id}")
	public Optional<Student> getStudentById(@PathVariable Long id) {
		return service.getStudentById(id);
	}
	
	@PutMapping("/student/{id}")
	public Student updateSudent(@RequestBody Student student, @PathVariable Long id) {
		return service.updateStudent(student, id);
	}
	
	@DeleteMapping("/student/{id}")
	public String deleteStudent(@PathVariable Long id) {
		service.deleteStudent(id);
		return "Student is deleted ";
	
		
	}

}
